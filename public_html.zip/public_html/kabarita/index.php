<!DOCTYPE html>
<html>
<head>
    <title>MPESA Callback Processing</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        p {
            color: green; /* Change this to your desired text color */
            font-size: 18px;
        }
        
        /* Apply styles to the body */
body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
    margin: 0;
    padding: 0;
}

/* Style the header */
h1 {
    color: #333;
    text-align: center;
    padding: 20px;
    background-color: #fff;
    border-bottom: 1px solid #ccc;
}

/* Style the form container */
form {
    max-width: 400px;
    margin: 0 auto;
    padding: 20px;
    background-color: #fff;
    border: 1px solid #ccc;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

/* Style labels and input fields */
label {
    display: block;
    margin-bottom: 5px;
    font-weight: bold;
    color: #555;
}

input[type="text"] {
    width: 100%;
    padding: 10px;
    margin-bottom: 15px;
    border: 1px solid #ccc;
    border-radius: 4px;
    transition: border-color 0.3s ease-in-out;
}

input[type="text"]:focus {
    border-color: #007bff;
    outline: none;
}

/* Style the submit button */
input[type="submit"] {
    display: block;
    width: 100%;
    padding: 10px;
    background-color: #007bff;
    color: #fff;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    transition: background-color 0.3s ease-in-out;
}

input[type="submit"]:hover {
    background-color: #0056b3;
}

/* Style success message */
p {
    color: green;
    font-size: 18px;
    text-align: center;
    margin-top: 20px;
}

        
        
        
    </style>
</head>
<body>
    <h1>MPESA Callback Processing</h1>
    <form action="stkpush.php" method="post">
        <label for="phone_number">Phone Number:</label>
        <input type="text" id="phone_number" name="phone_number" placeholder="eg. 0712345679"  required><br><br>
        
        <label for="amount">Amount:</label>
        <input type="text" id="amount" name="amount" placeholder="RENT/DEPOSIT" required><br><br>
        
        <input type="submit" value="Initiate STK Push">
    </form>
    
    <script>
        document.querySelector('form').addEventListener('submit', function (event) {
            const phoneNumberInput = document.getElementById('phone_number');
            const rawPhoneNumber = phoneNumberInput.value.trim();
            
            // Check if the number starts with '0'
            if (rawPhoneNumber.startsWith('0')) {
                // Remove the leading '0' and add '254' at the beginning
                const formattedPhoneNumber = '254' + rawPhoneNumber.substr(1);
                phoneNumberInput.value = formattedPhoneNumber;
            }
        });
        
            // Parse the URL to get the query string
        const queryString = window.location.search;
        
        // Create a new URLSearchParams object with the query string
        const params = new URLSearchParams(queryString);
        
        // Get the value of the 'message' parameter
        const message = params.get('message');
        
        // Display the message on the page
        if (message) {
            const messageElement = document.createElement('p');
            messageElement.textContent = message;
            document.body.appendChild(messageElement);
        }  
        
    </script>
</body>
</html>
