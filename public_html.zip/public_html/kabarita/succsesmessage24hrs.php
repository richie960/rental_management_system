<?php
include 'dbconnection.php';

// Get the list of distinct house numbers from your database
$houseNumbersQuery = "SELECT DISTINCT HouseNumber FROM transactions";
$houseNumbersResult = mysqli_query($db, $houseNumbersQuery);

if (!$houseNumbersResult) {
    echo "Error fetching house numbers: " . mysqli_error($db) . "\n";
    mysqli_close($db);
    exit();
}

while ($row = mysqli_fetch_assoc($houseNumbersResult)) {
    $houseNumber = $row['HouseNumber'];

    // Calculate total amount and twilosent for the house number
    $totalAmountQuery = "SELECT SUM(Amount) AS TotalAmount, twilosent, status FROM transactions WHERE LOWER(HouseNumber) = LOWER('$houseNumber')";
    $totalAmountResult = mysqli_query($db, $totalAmountQuery);

    if (!$totalAmountResult) {
        echo "Error calculating total amount: " . mysqli_error($db) . "\n";
        mysqli_close($db);
        exit();
    }

    $amountRow = mysqli_fetch_assoc($totalAmountResult);
    $totalAmount = $amountRow['TotalAmount'];
    $twiloSent = $amountRow['twilosent'];
    $status = $amountRow['status'];

    if ($twiloSent == 1) {
        echo "Message processed for House $houseNumber\n";
        continue; // Move to the next house number
    }

    if ($status == 1) {
        // Update twilosent to 1
        $updateTwiloSentQuery = "UPDATE transactions SET twilosent = 1 WHERE LOWER(HouseNumber) = LOWER('$houseNumber')";
        mysqli_query($db, $updateTwiloSentQuery);

        // Send message for the house number to all associated phone numbers
        $message = "Rent has been successfully paid for $houseNumber. Current amount: $totalAmount";

        $phoneQuery = "SELECT DISTINCT PhoneNumber FROM transactions WHERE LOWER(HouseNumber) = LOWER('$houseNumber')";
        $phoneResult = mysqli_query($db, $phoneQuery);

        if (!$phoneResult) {
            echo "Error fetching phone numbers: " . mysqli_error($db) . "\n";
            continue; // Move to the next house number
        }

        while ($phoneRow = mysqli_fetch_assoc($phoneResult)) {
            $phone = $phoneRow['PhoneNumber'];

            if (substr($phone, 0, 1) !== '+') {
                $phone = '+' . $phone;
            }

            // Use Twilio API to send the message
            require_once 'mambo ya twilio/twilio-php-main/src/Twilio/autoload.php';

            $accountSid = 'ACfb74a166be1471d08019215b98dfdb08';
            $authToken = '67ccf5114af52484046c2ba0f65eb98e';
            $twilio = new Twilio\Rest\Client($accountSid, $authToken);

            $twilio->messages->create(
                $phone, // Phone number to send the message to
                [
                    'from' => '+18788812603', // Your Twilio phone number
                    'body' => $message,
                ]
            );

            echo "Message sent for House $houseNumber to $phone\n";
        }
    }
}

// Close the database connection
mysqli_close($db);
?>
