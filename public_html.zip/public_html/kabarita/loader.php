<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
  body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    background-color: #f4f4f4;
  }

  #loading-container {
    text-align: center;
  }

  #loading {
    width: 0;
    height: 30px;
    background-color: #00cc00;
    transition: width 0.5s ease-in-out, background-color 2s ease-in-out;
  }
</style>
</head>
<body>
<div id="loading-container">
  <h2>Hang Tight! We're Getting Ready...</h2>
  <div id="loading"></div>
</div>

<script>
  function simulateLoading() {
    let loadingElement = document.getElementById("loading");
    let width = 0;
    let colors = ["#00cc00", "#ff6600", "#ff3300", "#ff0000"];
    let colorIndex = 0;

    let interval = setInterval(function() {
      if (width >= 100) {
        clearInterval(interval);
        window.location.href = "callback.php";
      } else {
        width++;
        loadingElement.style.width = width + "%";
        if (width % 10 === 0) {
          colorIndex = (colorIndex + 1) % colors.length;
          loadingElement.style.backgroundColor = colors[colorIndex];
        }
      }
    }, 200);
  }

  simulateLoading();
</script>
</body>
</html>
