<?php
include 'dbconnection.php';

if (isset($_POST['phone_number']) && isset($_POST['new_house_number'])) {
    $phoneNumber = $_POST['phone_number'];
    $newHouseNumber = $_POST['new_house_number'];

    // Check if the phone number exists in the database
    $checkQuery = "SELECT * FROM transactions WHERE PhoneNumber = '$phoneNumber'";
    $checkResult = mysqli_query($db, $checkQuery);

    if (!$checkResult) {
        echo "Error checking phone number: " . mysqli_error($db) . "\n";
        mysqli_close($db);
        exit();
    }

    if (mysqli_num_rows($checkResult) > 0) {
        $row = mysqli_fetch_assoc($checkResult);
        $existingHouseNumber = $row['HouseNumber'];

        if (empty($existingHouseNumber)) {
            // Update the HouseNumber field with the new value
            $updateQuery = "UPDATE transactions SET HouseNumber = '$newHouseNumber' WHERE PhoneNumber = '$phoneNumber'";
            if (mysqli_query($db, $updateQuery)) {
               // echo "House number updated successfully.\n";
                mysqli_close($db);
                // Redirect to success page
           
              header ("Location: index.php?message=House+number+updated+successfully.");
                exit();
            } else {
               // echo "Error updating house number: " . mysqli_error($db) . "\n";
                mysqli_close($db);
                // Redirect to error page
                header("Location: index.php?message= error updating your info get admin");
                exit();
            }
        } else {
            // HouseNumber already filled, prevent duplicate entry
          //  echo "House number is already filled for this phone number.\n";
              header("Location: index.php?message= it seems your already registred😁 ");
        }
    } else {
       // echo "Phone number not found in the database.\n";
       header("Location: index.php?message=phone number is not registered enter correct details dont paste link and use");
    }

    // Close the database connection
    mysqli_close($db);
} else {
  //  echo "Phone number and new house number are required.\n";
   header("Location: index.php?message= enter all details");
}
?>
