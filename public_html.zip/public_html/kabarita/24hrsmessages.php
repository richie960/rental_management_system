<?php
include 'dbconnection.php';

// Get the list of distinct house numbers from your database
$houseNumbersQuery = "SELECT DISTINCT HouseNumber FROM transactions";
$houseNumbersResult = mysqli_query($db, $houseNumbersQuery);

if (!$houseNumbersResult) {
    echo "Error fetching house numbers: " . mysqli_error($db) . "\n";
    mysqli_close($db);
    exit();
}

require_once 'mambo ya twilio/twilio-php-main/src/Twilio/autoload.php'; // Include the Twilio library

$accountSid = 'ACfb74a166be1471d08019215b98dfdb08'; // Replace with your Twilio account SID
$authToken = '67ccf5114af52484046c2ba0f65eb98e';
//th token

$twilio = new Twilio\Rest\Client($accountSid, $authToken); // Instantiate Twilio client

while ($row = mysqli_fetch_assoc($houseNumbersResult)) {
    $houseNumber = $row['HouseNumber'];

    // Calculate total amount for the house number
    $totalAmountQuery = "SELECT SUM(Amount) AS TotalAmount FROM transactions WHERE LOWER(HouseNumber) = LOWER('$houseNumber')";
    $totalAmountResult = mysqli_query($db, $totalAmountQuery);

    if (!$totalAmountResult) {
        echo "Error calculating total amount: " . mysqli_error($db) . "\n";
        mysqli_close($db);
        exit();
    }

    $amountRow = mysqli_fetch_assoc($totalAmountResult);
    $totalAmount = $amountRow['TotalAmount'];

    // Search for the house number in the default deposit table
    $defaultQuery = "SELECT * FROM default_deposits WHERE LOWER(HouseNumber) = LOWER('$houseNumber')";
    $defaultResult = mysqli_query($db, $defaultQuery);

    if (!$defaultResult) {
        echo "Error searching default deposit: " . mysqli_error($db) . "\n";
        mysqli_close($db);
        exit();
    }

    if (mysqli_num_rows($defaultResult) > 0) {
        $defaultRow = mysqli_fetch_assoc($defaultResult);
        $defaultDeposit = $defaultRow['DefaultDeposit'];

        if ($totalAmount < $defaultDeposit) {
            // Send message for the house number
            $message = "Please pay your rent for House $houseNumber. Current amount: $totalAmount";

            // Get all phone numbers associated with the house number
            $phoneQuery = "SELECT DISTINCT PhoneNumber FROM transactions WHERE LOWER(HouseNumber) = LOWER('$houseNumber')";
            $phoneResult = mysqli_query($db, $phoneQuery);

            if (!$phoneResult) {
                echo "Error fetching phone numbers: " . mysqli_error($db) . "\n";
                mysqli_close($db);
                exit();
            }

            while ($phoneRow = mysqli_fetch_assoc($phoneResult)) {
                $phone = $phoneRow['PhoneNumber'];

                // Assuming $phone contains the phone number from the database
                if (substr($phone, 0, 1) !== '+') {
                    $phone = '+' . $phone;
                }

                $twilio->messages->create(
                    $phone, // Phone number to send the message to
                    [
                        'from' => '+18788812603', // Your Twilio phone number
                        'body' => $message,
                    ]
                );

                echo "Message sent for House $houseNumber to $phone\n";
            }
        } else {
            // Update status to 1 and open another page
            $updateStatusQuery = "UPDATE transactions SET status = 1 WHERE LOWER(HouseNumber) = LOWER('$houseNumber')";
            mysqli_query($db, $updateStatusQuery);
            echo "Updated status for House $houseNumber: $totalAmount\n";
        }
    }
}

// Close the database connection
mysqli_close($db);
?>
