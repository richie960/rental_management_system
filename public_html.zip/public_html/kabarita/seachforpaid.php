<?php
include 'dbconnection.php';

$searchResult = '';
if (isset($_GET['search'])) {
    $searchHouseNumber = $_GET['search'];
    $searchQuery = "SELECT dd.HouseNumber, dd.DefaultDeposit, 
                           CASE WHEN t.status = 1 THEN 'Paid' ELSE 'Not Paid' END AS status, 
                           t.Amount 
                    FROM default_deposits dd
                    LEFT JOIN transactions t ON dd.HouseNumber = t.HouseNumber
                    WHERE dd.HouseNumber = '$searchHouseNumber'";
    $searchResult = mysqli_query($db, $searchQuery);
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search House Payment Status</title>
    <style>
    /* ... Your existing CSS styles ... */
    <style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f4f4f4;
    }

    .container {
        max-width: 800px;
        margin: 0 auto;
        padding: 20px;
        background-color: #fff;
        border-radius: 5px;
        box-shadow: 0px 0px 5px rgba(0, 0, 0, 0.2);
    }

    h2 {
        text-align: center;
        margin-bottom: 20px;
    }

    label {
        display: block;
        margin-bottom: 8px;
        font-weight: bold;
    }

    input[type="text"] {
        width: 100%;
        padding: 10px;
        margin-bottom: 20px;
        border: 1px solid #ccc;
        border-radius: 5px;
    }

    button {
        padding: 10px;
        background-color: #007bff;
        color: #fff;
        border: none;
        border-radius: 5px;
        cursor: pointer;
    }

    button:hover {
        background-color: #0056b3;
    }

    table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
    }

    th, td {
        padding: 10px;
        border: 1px solid #ccc;
        text-align: center;
    }

    p {
        text-align: center;
        color: #666;
    }
</style>

    </style>
</head>
<body>
    <div class="container">
        <h2>Search House Payment Status</h2>

        <form action="" method="get">
            <label for="search">Search House Number:</label>
            <input type="text" id="search" name="search" required>
            <button type="submit">Search</button>
        </form>

        <?php if ($searchResult && mysqli_num_rows($searchResult) > 0) { ?>
            <h3>Search Result:</h3>
            <table>
                <tr>
                    <th>House Number</th>
                    <th>Default Deposit</th>
                    <th>Status</th>
                    <th>Amount</th>
                </tr>
                <?php while ($row = mysqli_fetch_assoc($searchResult)) { ?>
                    <tr>
                        <td><?php echo $row['HouseNumber']; ?></td>
                        <td><?php echo $row['DefaultDeposit']; ?></td>
                        <td><?php echo $row['status']; ?></td>
                        <td><?php echo $row['Amount']; ?></td>
                    </tr>
                <?php } ?>
            </table>
        <?php } elseif ($searchResult && mysqli_num_rows($searchResult) === 0) { ?>
            <p>No results found for the given house number.</p>
        <?php } ?>

    </div>
</body>
</html>
