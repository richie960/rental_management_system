<?php
include 'accessToken.php';
include 'dbconnection.php';

$stkCallbackResponse = file_get_contents('php://input');
$logFile = "Mpesastkresponse.json";
$log = fopen($logFile, "a");
fwrite($log, $stkCallbackResponse);
fclose($log);

$data = json_decode($stkCallbackResponse);

$MerchantRequestID = $data->Body->stkCallback->MerchantRequestID;
$CheckoutRequestID = $data->Body->stkCallback->CheckoutRequestID;
$ReceivedAmount = (float) $data->Body->stkCallback->CallbackMetadata->Item[0]->Value; // Cast to float
$TransactionId = $data->Body->stkCallback->CallbackMetadata->Item[1]->Value;
$UserPhoneNumber = $data->Body->stkCallback->CallbackMetadata->Item[4]->Value;

// Search for the phone number in the database
$searchQuery = "SELECT * FROM transactions WHERE PhoneNumber = '$UserPhoneNumber'";
$searchResult = mysqli_query($db, $searchQuery);

if (mysqli_num_rows($searchResult) > 0) {
    // Fetch the existing record
    $existingRecord = mysqli_fetch_assoc($searchResult);

    // Update the existing record with the new amount
    $updateQuery = "UPDATE transactions 
                    SET MerchantRequestID = '$MerchantRequestID', 
                        CheckoutRequestID = '$CheckoutRequestID', 
                        Amount = Amount + $ReceivedAmount, 
                        MpesaReceiptNumber = '$TransactionId', 
                        PhoneNumber = '$UserPhoneNumber'
                    WHERE PhoneNumber = '$UserPhoneNumber'";

    if (mysqli_query($db, $updateQuery)) {
        // Redirect to another page using JavaScript
        echo '<script>window.location.href = "update_form.html?message=welcome";</script>';
        exit(); // Exit to prevent further output
    } else {
        echo "Error updating data: " . mysqli_error($db) . "\n";
    }
} else {
    // Insert a new record
    $insertQuery = "INSERT INTO transactions (MerchantRequestID, CheckoutRequestID, Amount, MpesaReceiptNumber, PhoneNumber)
                    VALUES ('$MerchantRequestID', '$CheckoutRequestID', $ReceivedAmount, '$TransactionId', '$UserPhoneNumber')";

    if (mysqli_query($db, $insertQuery)) {
        // Redirect to another page using JavaScript
        echo '<script>window.location.href = "update_form.html?message=welcome to kabarita general agency";</script>';
        exit(); // Exit to prevent further output
    } else {
        echo "Error inserting data: " . mysqli_error($db) . "\n";
    }
}

// Close the database connection
mysqli_close($db);
?>
