<?php
include 'accessToken.php';
date_default_timezone_set('Africa/Nairobi');
$processrequestUrl = 'https://sandbox.safaricom.co.ke/mpesa/stkpush/v1/processrequest';
$callbackurl = 'https://kabaritacoltd.000webhostapp.com/kabarita/callback.php';
$passkey = "bfb279f9aa9bdbcf158e97dd71a467cd2e0c893059b10f78e6b72ada1ed2c919";
$BusinessShortCode = '174379';
$Timestamp = date('YmdHis');
// ENCRYPT DATA TO GET PASSWORD
$Password = base64_encode($BusinessShortCode . $passkey . $Timestamp);

// Get user-provided data from the form
$phone = $_POST['phone_number'];
$money = $_POST['amount'];

$PartyA = $phone;
$PartyB = '254708374149';
$AccountReference = 'KABARITA GENERAL AGENCY';
$TransactionDesc = 'stkpush test';
$Amount = $money;
$stkpushheader = ['Content-Type:application/json', 'Authorization:Bearer ' . $access_token];
// INITIATE CURL
$curl = curl_init();
curl_setopt($curl, CURLOPT_URL, $processrequestUrl);
curl_setopt($curl, CURLOPT_HTTPHEADER, $stkpushheader); // setting custom header
$curl_post_data = array(
    // Fill in the request parameters with valid values
    'BusinessShortCode' => $BusinessShortCode,
    'Password' => $Password,
    'Timestamp' => $Timestamp,
    'TransactionType' => 'CustomerPayBillOnline',
    'Amount' => $Amount,
    'PartyA' => $PartyA,
    'PartyB' => $BusinessShortCode,
    'PhoneNumber' => $PartyA,
    'CallBackURL' => $callbackurl,
    'AccountReference' => $AccountReference,
    'TransactionDesc' => $TransactionDesc
);

$data_string = json_encode($curl_post_data);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl, CURLOPT_POST, true);
curl_setopt($curl, CURLOPT_POSTFIELDS, $data_string);
$curl_response = curl_exec($curl);
// ECHO RESPONSE
$data = json_decode($curl_response);

// Check if CheckoutRequestID and ResponseCode exist
if (isset($data->CheckoutRequestID) && isset($data->ResponseCode)) {
    $CheckoutRequestID = $data->CheckoutRequestID;
    $ResponseCode = $data->ResponseCode;
    
    if ($ResponseCode == "0") {
        // Redirect to callback page with house number parameter
        header("Location: loader.php");
        exit(); // Exit to prevent further output
    } else {
        // Handle error
        echo "Error response code: " . $ResponseCode;
    }
} else {
    // Handle JSON parsing error or missing properties
    echo "Error parsing JSON response or missing properties.";
}

curl_close($curl);
?>
